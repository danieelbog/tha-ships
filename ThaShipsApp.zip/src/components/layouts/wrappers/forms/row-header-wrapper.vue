<template>
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <slot></slot>
        </div>
    </div>
</template>
