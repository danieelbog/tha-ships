<template>
    <div class="container-fluid g-0">
        <router-view></router-view>
    </div>
</template>
