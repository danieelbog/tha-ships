export interface IAuthToken {
    token: string;
    remember: boolean;
}
